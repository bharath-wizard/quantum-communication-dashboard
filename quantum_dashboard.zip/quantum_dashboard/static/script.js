function showMessage(){
    alert(
    "Welcome to the Quantum Communication Dashboard!\n\nLet's begin learning Quantum Computing."
    );
}

/* ==========================
   Gate-by-gate state evolution player
   ========================== */

function initEvolutionPlayer(evolutionData) {
    const steps = evolutionData;
    let current = 0;
    let playing = false;
    let playTimer = null;

    const gateNameEl = document.getElementById("gateName");
    const stepBadgeEl = document.getElementById("stepBadge");
    const descriptionEl = document.getElementById("gateDescription");
    const ketEl = document.getElementById("ketDisplay");
    const barsEl = document.getElementById("probBars");
    const dotsEl = document.getElementById("stepDots");
    const prevBtn = document.getElementById("prevBtn");
    const nextBtn = document.getElementById("nextBtn");
    const playBtn = document.getElementById("playBtn");

    // build step dots once
    steps.forEach((_, i) => {
        const dot = document.createElement("div");
        dot.className = "step-dot" + (i === 0 ? " active" : "");
        dot.dataset.index = i;
        dot.addEventListener("click", () => { stopPlaying(); render(i); });
        dotsEl.appendChild(dot);
    });

    function render(index) {
        current = index;
        const step = steps[current];

        stepBadgeEl.textContent = `STEP ${current} / ${steps.length - 1}`;
        gateNameEl.textContent = step.gate;
        descriptionEl.textContent = step.description;
        ketEl.textContent = "|psi> = " + step.ket;

        // probability bars for each surviving basis state
        barsEl.innerHTML = "";
        step.terms.forEach(term => {
            const col = document.createElement("div");
            col.className = "prob-bar-col";

            const value = document.createElement("div");
            value.className = "prob-bar-value";
            value.textContent = Math.round(term.probability * 100) + "%";

            const bar = document.createElement("div");
            bar.className = "prob-bar";
            bar.style.height = "0px";

            const label = document.createElement("div");
            label.className = "prob-bar-label";
            label.textContent = "|" + term.label + ">";

            col.appendChild(value);
            col.appendChild(bar);
            col.appendChild(label);
            barsEl.appendChild(col);

            requestAnimationFrame(() => {
                bar.style.height = Math.max(term.probability * 130, 3) + "px";
            });
        });

        // update dots
        Array.from(dotsEl.children).forEach((dot, i) => {
            dot.classList.toggle("active", i === current);
        });

        prevBtn.disabled = current === 0;
        nextBtn.disabled = current === steps.length - 1;
    }

    function stopPlaying() {
        playing = false;
        playBtn.textContent = "▶ Play";
        if (playTimer) clearInterval(playTimer);
    }

    prevBtn.addEventListener("click", () => { stopPlaying(); if (current > 0) render(current - 1); });
    nextBtn.addEventListener("click", () => { stopPlaying(); if (current < steps.length - 1) render(current + 1); });

    playBtn.addEventListener("click", () => {
        if (playing) {
            stopPlaying();
            return;
        }
        playing = true;
        playBtn.textContent = "⏸ Pause";
        if (current === steps.length - 1) render(0);
        playTimer = setInterval(() => {
            if (current < steps.length - 1) {
                render(current + 1);
            } else {
                stopPlaying();
            }
        }, 1400);
    });

    render(0);
}

/* ==========================
   Measurement results bar chart
   ========================== */

function initResultsChart(counts) {
    const chartEl = document.getElementById("resultsChart");
    if (!chartEl) return;

    const entries = Object.entries(counts).sort((a, b) => b[1] - a[1]);
    const max = Math.max(...entries.map(([, c]) => c));

    entries.forEach(([label, count]) => {
        const col = document.createElement("div");
        col.className = "result-col";

        const value = document.createElement("div");
        value.className = "result-count";
        value.textContent = count;

        const bar = document.createElement("div");
        bar.className = "result-bar";
        bar.style.height = "0px";

        const lbl = document.createElement("div");
        lbl.className = "result-label";
        lbl.textContent = label;

        col.appendChild(value);
        col.appendChild(bar);
        col.appendChild(lbl);
        chartEl.appendChild(col);

        requestAnimationFrame(() => {
            bar.style.height = Math.max((count / max) * 180, 3) + "px";
        });
    });

    const toggleBtn = document.getElementById("rawToggle");
    const rawEl = document.getElementById("rawCounts");
    if (toggleBtn && rawEl) {
        toggleBtn.addEventListener("click", () => {
            const visible = rawEl.style.display === "block";
            rawEl.style.display = visible ? "none" : "block";
            toggleBtn.textContent = visible ? "Show raw counts" : "Hide raw counts";
        });
    }
}
