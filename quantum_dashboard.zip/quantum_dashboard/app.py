import json
from flask import Flask, render_template

from quantum.bell_states import create_bell, run_circuit, get_evolution as bell_evolution, \
    save_circuit as save_bell_circuit, save_histogram as save_bell_hist
from quantum.entanglement import create_entanglement, run_entanglement, get_evolution as ent_evolution, \
    save_circuit as save_ent_circuit, save_histogram as save_ent_hist
from quantum.teleportation import create_teleportation, run_teleportation, verify_teleportation, \
    get_evolution as tel_evolution, save_circuit as save_tel_circuit, save_histogram as save_tel_hist

app = Flask(__name__)


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/bell")
def bell():
    qc = create_bell()
    counts = run_circuit(qc)
    circuit_img = save_bell_circuit(qc)
    hist_img = save_bell_hist(counts)
    return render_template(
        "bell.html",
        counts=counts,
        counts_json=json.dumps(counts),
        evolution=bell_evolution(),
        circuit_img=circuit_img,
        hist_img=hist_img,
    )


@app.route("/entanglement")
def entanglement():
    qc = create_entanglement()
    counts = run_entanglement(qc)
    circuit_img = save_ent_circuit(qc)
    hist_img = save_ent_hist(counts)
    return render_template(
        "entanglement.html",
        counts=counts,
        counts_json=json.dumps(counts),
        evolution=ent_evolution(),
        circuit_img=circuit_img,
        hist_img=hist_img,
    )


@app.route("/teleportation")
def teleportation():
    qc = create_teleportation()
    counts = run_teleportation(qc)
    verification = verify_teleportation(counts)
    circuit_img = save_tel_circuit(qc)
    hist_img = save_tel_hist(counts)
    return render_template(
        "teleportation.html",
        counts=counts,
        counts_json=json.dumps(counts),
        evolution=tel_evolution(),
        circuit_img=circuit_img,
        hist_img=hist_img,
        verification=verification,
    )


if __name__ == "__main__":
    app.run(debug=True, port=8001)
