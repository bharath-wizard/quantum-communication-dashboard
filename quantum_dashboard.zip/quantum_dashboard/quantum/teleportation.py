import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from qiskit import QuantumCircuit
from qiskit_aer import AerSimulator
from qiskit.visualization import plot_histogram

from .state_utils import build_evolution

STATIC_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "static", "generated")

# The "unknown" state we are teleporting, prepared with Ry(theta) on q0.
# Using an angle that is not a "nice" 0/90/180 case makes the demo convincing:
# if teleportation works, q2's measurement statistics should reproduce these
# probabilities exactly, even though q2 never directly interacted with q0.
THETA = 2 * np.pi / 5
P0_ORIGINAL = float(np.cos(THETA / 2) ** 2)
P1_ORIGINAL = float(np.sin(THETA / 2) ** 2)


def create_teleportation():
    """
    Full teleportation protocol:
      q0 = the qubit whose state we teleport (unknown to Bob)
      q1 = Alice's half of an entangled pair
      q2 = Bob's half of the entangled pair (receives the state)

      c0, c1 = Alice's Bell-measurement results, sent to Bob classically
      c2     = Bob's final measurement of the teleported qubit

    Bob applies an X correction if c1 == 1 and a Z correction if c0 == 1,
    which is what actually completes the protocol.
    """
    qc = QuantumCircuit(3, 3)

    # Step 1: prepare the "unknown" state to teleport on q0
    qc.ry(THETA, 0)

    # Step 2: create an entangled Bell pair between q1 (Alice) and q2 (Bob)
    qc.h(1)
    qc.cx(1, 2)

    # Step 3: Alice performs a Bell measurement on q0 and her half (q1)
    qc.cx(0, 1)
    qc.h(0)
    qc.measure(0, 0)
    qc.measure(1, 1)

    # Step 4: Bob applies classically-controlled corrections to q2
    with qc.if_test((qc.clbits[1], 1)):
        qc.x(2)
    with qc.if_test((qc.clbits[0], 1)):
        qc.z(2)

    # Step 5: Bob measures the teleported qubit
    qc.measure(2, 2)

    return qc


def run_teleportation(qc, shots=1024):
    simulator = AerSimulator()
    result = simulator.run(qc, shots=shots).result()
    return result.get_counts()


def verify_teleportation(counts):
    """
    Marginalize over Alice's measurement outcomes (c0, c1) and look only
    at Bob's qubit (c2, the leftmost bit in Qiskit's c2 c1 c0 ordering).
    If teleportation worked, P(q2=0) and P(q2=1) should match the
    original state's probabilities regardless of which Bell outcome
    Alice got.
    """
    total = sum(counts.values())
    p2_0 = sum(c for bits, c in counts.items() if bits[0] == "0") / total
    p2_1 = sum(c for bits, c in counts.items() if bits[0] == "1") / total

    return {
        "original_p0": round(P0_ORIGINAL, 4),
        "original_p1": round(P1_ORIGINAL, 4),
        "teleported_p0": round(p2_0, 4),
        "teleported_p1": round(p2_1, 4),
        "max_error": round(max(abs(p2_0 - P0_ORIGINAL), abs(p2_1 - P1_ORIGINAL)), 4),
    }


def get_evolution():
    """
    Statevector evolution for the unitary part of the protocol only
    (state prep -> Bell pair creation -> Bell-basis rotation), since
    measurement and classical correction aren't unitary and can't be
    shown as a single evolving ket. The final step is described in
    words instead.
    """
    steps = [
        {
            "name": "Ry(theta) (q0)",
            "description": "Prepare q0 in the 'unknown' state we want to teleport: "
                            f"a superposition weighted {P0_ORIGINAL:.0%} toward |0> and "
                            f"{P1_ORIGINAL:.0%} toward |1>.",
            "apply": lambda qc: qc.ry(THETA, 0),
        },
        {
            "name": "H (q1)",
            "description": "Start building the entangled pair Alice and Bob will share: "
                            "superpose qubit 1.",
            "apply": lambda qc: qc.h(1),
        },
        {
            "name": "CX (q1 -> q2)",
            "description": "Entangle qubits 1 and 2 into a Bell pair. Alice keeps q1, "
                            "Bob keeps q2 - they can be physically far apart from here on.",
            "apply": lambda qc: qc.cx(1, 2),
        },
        {
            "name": "CX (q0 -> q1)",
            "description": "Alice starts a Bell-basis measurement by entangling the qubit "
                            "she wants to teleport (q0) with her half of the pair (q1).",
            "apply": lambda qc: qc.cx(0, 1),
        },
        {
            "name": "H (q0)",
            "description": "Alice finishes rotating into the Bell basis. All 3 qubits are now "
                            "entangled together - q0's original information is smeared across "
                            "the whole system.",
            "apply": lambda qc: qc.h(0),
        },
    ]
    return build_evolution(3, steps)


def save_histogram(counts, filename="teleportation_histogram.png"):
    os.makedirs(STATIC_DIR, exist_ok=True)
    fig = plot_histogram(counts)
    path = os.path.join(STATIC_DIR, filename)
    fig.savefig(path, bbox_inches="tight", dpi=120)
    plt.close(fig)
    return f"generated/{filename}"


def save_circuit(qc, filename="teleportation_circuit.png"):
    os.makedirs(STATIC_DIR, exist_ok=True)
    fig = qc.draw(output="mpl")
    path = os.path.join(STATIC_DIR, filename)
    fig.savefig(path, bbox_inches="tight", dpi=120)
    plt.close(fig)
    return f"generated/{filename}"


if __name__ == "__main__":
    qc = create_teleportation()
    print(qc)
    counts = run_teleportation(qc)
    print(counts)
    print(verify_teleportation(counts))
    save_circuit(qc)
    save_histogram(counts)
