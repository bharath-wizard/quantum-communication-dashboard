"""
Shared helpers for turning a Qiskit circuit into a step-by-step,
human-readable statevector evolution that the frontend can animate.

The core idea: rebuild the circuit gate-by-gate using only the
unitary part of the circuit (no measurement / no classical control),
and after each gate compute the statevector. Measurement and
classical corrections are described separately since they aren't
part of the pre-measurement state evolution.
"""

from qiskit import QuantumCircuit
from qiskit.quantum_info import Statevector
import numpy as np


def _ket_label(index, n_qubits):
    """binary string label for basis state index, e.g. 2, 2 -> '10'"""
    return format(index, f"0{n_qubits}b")


def statevector_to_terms(sv: Statevector, n_qubits: int, round_to=3):
    """
    Convert a Statevector into a list of {label, amplitude_re, amplitude_im,
    probability} for every basis state with non-negligible amplitude.
    """
    amps = np.round(sv.data, round_to)
    terms = []
    for i, amp in enumerate(amps):
        prob = float(np.round(abs(amp) ** 2, round_to))
        if prob < 1e-4 and abs(amp) < 1e-4:
            continue
        terms.append({
            "label": _ket_label(i, n_qubits),
            "re": float(np.round(amp.real, round_to)),
            "im": float(np.round(amp.imag, round_to)),
            "probability": prob,
        })
    return terms


def ket_string(terms, n_qubits):
    """
    Build a plain-text Dirac notation string like '0.71|00> + 0.71|11>'
    from a list of terms (as produced by statevector_to_terms).
    """
    parts = []
    for t in terms:
        re, im = t["re"], t["im"]
        if abs(im) < 1e-9:
            coeff = f"{re:.3f}"
        elif abs(re) < 1e-9:
            coeff = f"{im:.3f}i"
        else:
            sign = "+" if im >= 0 else "-"
            coeff = f"({re:.3f}{sign}{abs(im):.3f}i)"
        parts.append(f"{coeff}|{t['label']}>")
    if not parts:
        return "0"
    out = parts[0]
    for p in parts[1:]:
        out += f" + {p}" if not p.startswith("-") else f" {p}"
    return out


def build_evolution(n_qubits, gate_steps, initial_label=None):
    """
    gate_steps: list of dicts:
        {"name": "H", "qubits": [0], "description": "..."}
        supported names: h, x, z, cx, ry(angle), etc. via 'apply' callback
        Each step dict must include an 'apply' callable that takes a
        QuantumCircuit and applies the gate to it.

    Returns a list of step dicts ready for JSON, each containing the
    gate applied, a description, the resulting ket string, and the
    term breakdown for rendering probability bars.
    """
    qc = QuantumCircuit(n_qubits)
    evolution = []

    sv0 = Statevector.from_instruction(qc)
    terms0 = statevector_to_terms(sv0, n_qubits)
    evolution.append({
        "step": 0,
        "gate": "Initial state",
        "description": initial_label or f"All {n_qubits} qubits start in |{'0'*n_qubits}>.",
        "ket": ket_string(terms0, n_qubits),
        "terms": terms0,
    })

    for i, step in enumerate(gate_steps, start=1):
        step["apply"](qc)
        sv = Statevector.from_instruction(qc)
        terms = statevector_to_terms(sv, n_qubits)
        evolution.append({
            "step": i,
            "gate": step["name"],
            "description": step["description"],
            "ket": ket_string(terms, n_qubits),
            "terms": terms,
        })

    return evolution
