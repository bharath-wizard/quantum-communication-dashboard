import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from qiskit import QuantumCircuit
from qiskit_aer import AerSimulator
from qiskit.visualization import plot_histogram

from .state_utils import build_evolution

STATIC_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "static", "generated")


def create_bell():
    """Bell state (|00> + |11>) / sqrt(2)"""
    qc = QuantumCircuit(2, 2)
    qc.h(0)
    qc.cx(0, 1)
    qc.measure([0, 1], [0, 1])
    return qc


def run_circuit(qc, shots=1024):
    simulator = AerSimulator()
    result = simulator.run(qc, shots=shots).result()
    return result.get_counts()


def get_evolution():
    """Gate-by-gate statevector evolution (no measurement) for the UI."""
    steps = [
        {
            "name": "H (q0)",
            "description": "Hadamard puts qubit 0 into an equal superposition of |0> and |1>, "
                            "while qubit 1 stays at |0>.",
            "apply": lambda qc: qc.h(0),
        },
        {
            "name": "CX (q0 -> q1)",
            "description": "Controlled-NOT flips qubit 1 only in the branch where qubit 0 is |1>. "
                            "This entangles the two qubits: they can no longer be described independently.",
            "apply": lambda qc: qc.cx(0, 1),
        },
    ]
    return build_evolution(2, steps)


def save_histogram(counts, filename="bell_histogram.png"):
    os.makedirs(STATIC_DIR, exist_ok=True)
    fig = plot_histogram(counts)
    path = os.path.join(STATIC_DIR, filename)
    fig.savefig(path, bbox_inches="tight", dpi=120)
    plt.close(fig)
    return f"generated/{filename}"


def save_circuit(qc, filename="bell_circuit.png"):
    os.makedirs(STATIC_DIR, exist_ok=True)
    fig = qc.draw(output="mpl")
    path = os.path.join(STATIC_DIR, filename)
    fig.savefig(path, bbox_inches="tight", dpi=120)
    plt.close(fig)
    return f"generated/{filename}"


def main():
    qc = create_bell()
    print(qc)
    counts = run_circuit(qc)
    print(counts)
    save_circuit(qc)
    save_histogram(counts)


if __name__ == "__main__":
    main()
