import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from qiskit import QuantumCircuit
from qiskit_aer import AerSimulator
from qiskit.visualization import plot_histogram

from .state_utils import build_evolution

STATIC_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "static", "generated")


def create_entanglement():
    """
    GHZ state across 3 qubits: (|000> + |111>) / sqrt(2)

    This is a distinct circuit from the Bell-state page: it shows
    entanglement extending beyond just a pair of qubits, so all three
    qubits collapse together on measurement.
    """
    qc = QuantumCircuit(3, 3)
    qc.h(0)
    qc.cx(0, 1)
    qc.cx(1, 2)
    qc.measure([0, 1, 2], [0, 1, 2])
    return qc


def run_entanglement(qc, shots=1024):
    simulator = AerSimulator()
    result = simulator.run(qc, shots=shots).result()
    return result.get_counts()


def get_evolution():
    steps = [
        {
            "name": "H (q0)",
            "description": "Hadamard on qubit 0 creates a superposition of |0> and |1>. "
                            "Qubits 1 and 2 are still separately |0>.",
            "apply": lambda qc: qc.h(0),
        },
        {
            "name": "CX (q0 -> q1)",
            "description": "Qubit 1 becomes entangled with qubit 0: it flips to |1> only in the "
                            "branch where qubit 0 is |1>.",
            "apply": lambda qc: qc.cx(0, 1),
        },
        {
            "name": "CX (q1 -> q2)",
            "description": "Qubit 2 is chained into the same entangled branch. All three qubits "
                            "now rise or fall together: (|000> + |111>)/sqrt(2), a GHZ state.",
            "apply": lambda qc: qc.cx(1, 2),
        },
    ]
    return build_evolution(3, steps)


def save_histogram(counts, filename="entanglement_histogram.png"):
    os.makedirs(STATIC_DIR, exist_ok=True)
    fig = plot_histogram(counts)
    path = os.path.join(STATIC_DIR, filename)
    fig.savefig(path, bbox_inches="tight", dpi=120)
    plt.close(fig)
    return f"generated/{filename}"


def save_circuit(qc, filename="entanglement_circuit.png"):
    os.makedirs(STATIC_DIR, exist_ok=True)
    fig = qc.draw(output="mpl")
    path = os.path.join(STATIC_DIR, filename)
    fig.savefig(path, bbox_inches="tight", dpi=120)
    plt.close(fig)
    return f"generated/{filename}"


if __name__ == "__main__":
    qc = create_entanglement()
    print(qc)
    print(run_entanglement(qc))
    save_circuit(qc)
    save_histogram(run_entanglement(qc))
